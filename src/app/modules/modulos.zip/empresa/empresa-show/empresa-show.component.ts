import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-show',
  templateUrl: './empresa-show.component.html',
  styleUrls: ['./empresa-show.component.scss']
})
export class EmpresaShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

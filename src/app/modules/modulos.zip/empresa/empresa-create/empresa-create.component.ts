import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-create',
  templateUrl: './empresa-create.component.html',
  styleUrls: ['./empresa-create.component.scss']
})
export class EmpresaCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

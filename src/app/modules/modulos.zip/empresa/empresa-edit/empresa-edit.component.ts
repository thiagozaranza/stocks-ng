import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-edit',
  templateUrl: './empresa-edit.component.html',
  styleUrls: ['./empresa-edit.component.scss']
})
export class EmpresaEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

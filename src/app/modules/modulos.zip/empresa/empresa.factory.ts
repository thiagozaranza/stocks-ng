import { Empresa } from './empresa';

export function create(): Empresa {
    return {
        id: null,
        nome: null,
    };
}
export interface Empresa {
    id: number;
    nome: string;
}

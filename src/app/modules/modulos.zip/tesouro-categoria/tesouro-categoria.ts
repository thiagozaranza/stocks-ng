export interface TesouroCategoria {
    id: number;
    nome: string;
    created_at: string;
    updated_at: string;
}
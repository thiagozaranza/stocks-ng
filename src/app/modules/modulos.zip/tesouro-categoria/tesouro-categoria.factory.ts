import { TesouroCategoria } from './tesouro-categoria';

export function create(): TesouroCategoria {
    return {
        id: null,
        nome: null,
        created_at: null,
        updated_at: null,
    };
}
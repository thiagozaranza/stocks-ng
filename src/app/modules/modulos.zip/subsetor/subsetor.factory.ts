import { Subsetor } from './subsetor';

export function create(): Subsetor {
    return {
        id: null,
        nome: null,
        segmentos: null,
        created_at: null,
        created_by: null,
        updated_at: null,
        updated_by: null,
    };
}
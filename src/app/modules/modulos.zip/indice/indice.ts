export interface Indice {
    id: number;
    nome: string;
    codigo: string;
    titulo: string;
    descricao: string;
    created_at: string;
    updated_at: string;
}